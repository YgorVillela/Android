package br.com.fiap.exerciciopalindrome;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    EditText edtFrase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtFrase = findViewById(R.id.edtFrase);
    }

    public void verificar(View view) {
        String s = "";


        System.out.println("Digite uma frase");
        edtFrase.getText();
        
        String inverte = new StringBuilder(s).reverse().toString();

        if(s.equals(inverte)){
            Toast.makeText(this, "Palindromo", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Não é palindromo", Toast.LENGTH_SHORT).show();
        }




    }
}
